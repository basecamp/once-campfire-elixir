import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
META = ROOT / 'var/final-cache-benchmark'
PRIMARY = pathlib.Path('/home/user/workspace/repo')
VERIFIED = pathlib.Path('/home/user/workspace/verify-statement-cache-linux')
EXPECTED = 'd95a406a33915790b632420d97840c96d76e4bd8a5e7595c58bdf2d84bf58efe'
SOURCE = '115cabc787bd3ed7bb6ccba5a6d9d6a4fc7e5948'

def command(args, cwd=ROOT):
    return subprocess.check_output(args, cwd=cwd, text=True).strip()

def source_files(root):
    paths = []
    for folder in ['lib', 'native', 'priv', 'vectors', 'hooks', 'test', 'tools/rails-to-elixir/lib', 'bin']:
        paths += [p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [root / x for x in ['mix.exs', 'mix.lock', 'Dockerfile', 'Dockerfile.dev', 'migration.toml']]
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

assert command(['git', 'rev-parse', 'HEAD']) == SOURCE
assert command(['python3', 'bench/validate.py', 'digest']) == EXPECTED
assert command(['python3', 'bench/validate.py', 'digest'], VERIFIED) == EXPECTED
current, verified = source_files(ROOT), source_files(VERIFIED)
assert current == verified
(META / 'canonical-app-files.json').write_text(json.dumps(current, indent=2) + '\n')
assert command(['git', '-C', 'reference', 'rev-parse', 'HEAD']) == '90b330024dec3e757c79b6a7e6568f93da8e3148'
assert command(['git', '-C', 'reference', 'status', '--short']) == ''
assert command(['git', 'diff', '--name-only', 'bbbf7010d8b5d38e1739c6168667eee869e8b5f5', 'HEAD']).splitlines() == [
    'bench/loadgen/src/main.rs', 'bench/report', 'tools/rails-to-elixir/tests/test_benchmark.py']
bundle = PRIMARY / '.amp/in/artifacts/statement-cache-and-wire-source.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == 'c8aaa1cbfdae94cfc5d947a158465772a50e66f9e022a4148c856aaa087ca1fa'
ledger = ROOT / 'parity/results/verification.json'
assert ledger.read_bytes() == (VERIFIED / 'parity/results/verification.json').read_bytes()
assert json.loads(ledger.read_text())['source_digest'] == EXPECTED
subprocess.run(['python3', 'bench/validate.py', 'ledger'], cwd=ROOT, check=True)
harness_paths = ['bench/run', 'bench/report', 'bench/validate.py', 'bench/validate-results.py', 'bench/job-state.py',
    'bench/loadgen/src/main.rs', 'bench/loadgen/Cargo.toml', 'bench/loadgen/Cargo.lock', 'tools/rails-to-elixir/tests/test_benchmark.py',
    'bench/lib/procmem.py', 'bench/lib/benchlib.py']
harness = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in harness_paths}
(META / 'harness-files.json').write_text(json.dumps(harness, indent=2) + '\n')
for filename, paths in [('prior-archives.sha256', list((PRIMARY / '.amp/in/artifacts').glob('*.tar.gz')) + list((PRIMARY / '.amp/in/artifacts').glob('*.bundle'))),
                         ('seed-before.sha256', [p for p in (PRIMARY / 'var/linux-benchmark-setup/seed/default').rglob('*') if p.is_file()])]:
    with (META / filename).open('w') as file:
        for path in sorted(paths): file.write(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path}\n')
images = {}
for label, image in [('baseline', 'sha256:7cb5658090eee9c77c4d19572766434bb4a2b6654b80334bb8f43df02f922182'),
                     ('candidate', 'sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5')]:
    data = json.loads(command(['docker', 'image', 'inspect', image]))[0]
    assert data['Id'] == image and data['Architecture'] == 'amd64' and data['Os'] == 'linux'
    images[label] = {k: data[k] for k in ['Id', 'Architecture', 'Os', 'Size', 'Created', 'RootFS']}
receipt = {'passed': True, 'harness_revision': SOURCE, 'application_digest': EXPECTED, 'canonical_files_equal': len(current),
    'runtime_build_provenance': '6f06e50 plus verified three-file statement-cache overlay; not rebuilt from 115cabc',
    'source_equivalent_to': SOURCE, 'reused_parity_ledger_sha256': hashlib.sha256(ledger.read_bytes()).hexdigest(),
    'reused_parity_ledger_reason': 'byte-identical complete identity() inputs, independently compared path by path',
    'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(), 'images': images,
    'rust_image': 'rust@sha256:4cd829461bd5c4d511c32e269da9cb8929223b666519d8004e35fc8d1d771ab7'}
(META / 'provenance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
