# Final Linux baseline-versus-cache benchmark

Completed one authorized four-round run on 2026-10-05, 16:34:47–17:38:31 UTC:
3824.041 seconds (63m44s), including the cached load-generator build and quiet
waits. No retries, excluded cells, runtime overlays, source changes, tuning or
competing benchmark/build/profile work. No new timing is authorized by this receipt.

## Outcome and unresolved regressions

All 192 HTTP cells passed with 12,858,383 status-200/nonempty successes and no
transport/validation errors. All 24 Cable cases passed: 720 paced and 30,650
saturated accepted posts completed fanout to every subscribed client. All 40
uploads returned successful thumbnails. Every arm ended with 11 zero-job
observations spanning at least one second. Full schema-2 validation and the
independent companion audit passed on their first runs.

The candidate has meaningful throughput gains on sidebar, search and writes,
but is not a universal win. Median rate changes at c1/c16/c64:

| Route | c1 | c16 | c64 |
|---|---:|---:|---:|
| room_show | +14.0% | +19.4% | +5.9% |
| messages_page | +7.2% | +15.6% | +5.2% |
| sidebar | +18.1% | +63.3% | +62.4% |
| search | +32.2% | +54.3% | +43.2% |
| avatar | +6.4% | +3.8% | +0.5% |
| static_css | +0.5% | +3.5% | -2.4% |
| up | +33.0% | +35.3% | +33.9% |
| post_message | +67.5% | +45.0% | +29.1% |

Room c64 p99 rises from 260.031 [240.895–310.783] to
401.407 [341.247–401.663] ms, +54.4% in the median and +29.1–66.7%
in all four paired rounds. Messages c64 p99 rises from
210.239 [187.519–222.335] to 393.215 [378.879–402.687] ms,
+87.0% median and +73.2–102.0% paired. Messages c16 p99 is also worse:
61.855 to 78.879 ms, +27.5% median. Room c16 p99 is mixed across rounds.
Derived CPU/success at room64 and messages64 is +6.2% and +2.9%, respectively.

Cable100/500/1000 median complete fanouts/s improve +30.1%, +15.9%, +5.6%.
However, Cable1000 saturated all-client p99 rises from
158.207 [156.543–187.519] to 177.727 [161.023–194.303] ms, +12.3%
median and +0.4–24.1% paired. Connection establishment is slower in the
candidate median at all three populations; paced tails at 500/1000 are mixed.
Uploads improve from a 230.9 to 210.85 ms median of per-arm medians (-8.7%).

Sampled peak memory.current increases from 574.5 [543–611] to
620 [594–657] MiB (+7.9%). Kernel cgroup memory.peak increases from
591.5 [580–612] to 651 [632–661] MiB (+10.1%). Idle memory is similar.
These peaks cover the whole HTTP/Cable/upload arm, not a specific route.

`comparison.md` contains every throughput range, paired range, tail change,
wire-size range, Cable latency range and memory range. `http-summary.csv`
also retains all four individual values for every HTTP metric; `http-cells.csv`
contains all 192 cells. `other-metrics.json`/CSV retain every Cable and memory
value used in the companion comparison. The original frozen-harness
`report.md` remains untouched in the result directory.

## Exact identities and protocol

- Baseline image: `sha256:7cb5658090eee9c77c4d19572766434bb4a2b6654b80334bb8f43df02f922182`.
- Candidate image: `sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5`.
- Runtime build provenance: `6f06e50f2ec5dae69331c2c5dd033b4ac8849580`
  plus the exact verified three-file overlay. This is **not** a rebuild of the
  newer Git revision. Build metadata remains `GIT_REVISION=6f06e50-overlay-83343b42`,
  `APP_VERSION=statement-cache-integration`.
- Harness and source-equivalent checkout: `115cabc787bd3ed7bb6ccba5a6d9d6a4fc7e5948`.
  The only subsequent harness changes are the three null-wire reporting/test files.
- Application digest: `d95a406a33915790b632420d97840c96d76e4bd8a5e7595c58bdf2d84bf58efe`.
  All 689 identity-input files are path-by-path equal to the verified integration.
- Seed DB: `bda9a5cd61d78d53f377cf07ee9268741caebc19b94a6efe782cafe827efc8db`.
  All 18 seed files were preserved. Fresh copies per arm, with the existing
  fail-fast local webhook/push endpoint rewrites; no seed changes.
- Native Linux amd64, Elixir1.20.4/OTP29.1.1/JIT, default dirty IO10 on both;
  16 configured normal schedulers, four online; four dirty CPU schedulers.
  Candidate has four readonly readers, each with a 64-statement bounded cache;
  baseline uses the original serial DB owner. No runtime module compilation.
- Server CPUs0,2,4,6; load-generator CPUs8,10,12,14; process-memory sampler CPU15;
  server/load-generator nofile65536; unchanged production Thruster path.
- Four rounds: B1,C1,C2,B2,B3,C3,C4,B4. HTTP12 seconds, concurrency1/16/64,
  eight routes; unchanged per-route 2s c4 warmup. Cable100/500/1000 with 30 paced
  posts, 15s saturation/four posters. Upload5 per arm.
- Exact pre-start one-minute loads: 0.21,1.31,1.33,1.36,1.36,1.49,1.35,1.36.
  Quiet waits: 0,90,90,100,80,80,100,90 seconds. Both logged pre-start loads and
  saved sample `loadavg_start` agree; the unchanged gate is load<1.5.
- No workload-cgroup throttling. Whole-run server-CPU steal including waits
  was 0.086–0.093%; this does not prove uniform per-cell host conditions.

`env.txt` says `bench dirty: 1 files` because the new untracked result directory
already existed, not because benchmark source was edited. Before/after harness
hashes and `git diff -- bench` verify this. Parent commits were unpushed at the
time of this run; no push, publication, PR, commit or deployment occurred here.

## Correctness, smoke and provenance

The previous complete integration ledger is reused because the complete
application identity is byte-identical: 65/65 gates,1941 unit tests, strict
format/compile/Credo/Dialyzer, targeted DB tests, production mixed-write
visibility and forced-reader recovery. Copies of those receipts live in
`verified-integration/`; the original correctness archive remains unchanged.

Before timing, this new harness passed 37 toolkit tests and pinned Rust test1,
check and release build. The compiler image is
`rust@sha256:4cd829461bd5c4d511c32e269da9cb8929223b666519d8004e35fc8d1d771ab7`.
The load generator hash is
`6d5b5bc3ceb0125a5996a1517de04782763eb53c2b2fb7bc0d0e4967db144820`.
Real production smoke on both images passed deflate0 and1, complete fanouts
and drained jobs. Runtime identities, owner PIDs, BEAM hashes, PRAGMAs, readonly
checks, CPU affinity and FD limits are retained in `cable-smoke/`. These probes
were outside clean timing, not per-cell instrumentation.

`PRAGMA busy_timeout=0` is preserved and is not interpreted as absence of
Exqlite's custom busy handler. No PRAGMA was changed for a probe.

## Evidence limits

**Derived CPU/success is retained, but raw per-cell cgroup before/after counter
pairs are not. Raw/enriched load-generator records can be compared; CPU deltas
cannot be independently reconstructed from retained counters.** The audit checks
that the retained derived values are positive and used consistently; it does not
claim an independent cgroup reconstruction. No rerun was done for this limitation.

All measured non-deflate Cable wire rates are null/unmeasured, not zero. HTTP
`avg_bytes` is mean wire response-body bytes, excluding headers/framing; it is
integer-truncated by the load generator. All eight preflights have equal decoded
lengths by route. Search wire bodies are about 2.6% smaller in the candidate
(9,990 versus 10,259–10,272 bytes) despite equal 165,534-byte decoded preflight
lengths. No compression changes were made here; the capture does not establish
the cause or prove normalized equality of the differing dynamic body hashes.

Timed HTTP validates status200 and nonempty body for every response; populated,
decoded output and fixture integrity are checked in every arm's preflight.
The harness does not retain all response bodies or independently decode every
timed response. Protocol fanout and job drains are verified from retained data.

This is a same-host loopback workload with one authenticated user and one Cable
room, not a multi-user production-capacity or ARM64 claim. Four-round ranges are
not confidence intervals. Median p99 means median of per-cell p99s. Runtime
identities are from separate fresh-container smoke under matched configuration,
not intrusive observations of each timed arm. Memory phases and whole-container
peaks are distinct from live-connection capacity. No queue/dirty-handler samples
or tracing were added. Routing imbalance is not established as a cause here.

Do not combine this HTTP12 run with historical HTTP4 results, and do not regenerate
historical reports with the new null-wire harness. This comparison measures the
whole candidate versus untouched upstream, not statement-cache-only attribution.
The high-concurrency room/messages tradeoff remains explicit and unresolved.

## Reproduction and preservation

Full execution: `run-approved.sh`; frozen driver source: `bench/run` in archive.
Prechecks: `prechecks.sh` and `precheck-commands.txt`; smoke: `cable-smoke.py`
and redacted command log (ephemeral fixture cookies/passwords/CSRF omitted).
Source equivalence: `provenance.py`, `canonical-app-files.json`, `harness-files.json`.
Validation: `audit-commands.txt`, `audit-evidence.py`, `receipt.json`;
comparison derivation: `summarize.py`. Paths use the original standalone checkout.

From the archive root, without rerunning any workload:

```sh
sha256sum -c var/final-cache-benchmark/archive-files.sha256
python3 bench/validate-results.py check bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536
bench/report bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536 > /tmp/reproduced-report.md
cmp /tmp/reproduced-report.md bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536/report.md
```

Report byte reproduction used Python3.11.6. Other Python versions may round
floating-point memory summaries differently; preserve this original report.
SHA256: `6616b9c8d8a4d4fc80ee8c445f9557e85139791dc87a2b8664104e0d8cc5faac`.

The 309 new result files, including 224 raw workload records, are checksummed.
All previous archives, raw diagnostic manifests, the previous 309-file full run,
551-member selection manifest, original 88-file evidence and seed passed
preservation checks. Images remain immutable in the orb; the archive carries
their exact IDs/layers and runtime receipts, not multi-gigabyte image exports.
No measured attempt failed; the audit and report reproduction also passed first
time. One status-wait tool call was interrupted by an incoming reporting note;
the benchmark process continued unchanged and finished with exit0.
