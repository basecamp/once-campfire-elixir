{:ok, _} = Application.ensure_all_started(:campfire)
alias Campfire.DB

pragmas = fn owner ->
  Map.new(
    ["foreign_keys", "journal_mode", "synchronous", "cache_size", "mmap_size",
     "busy_timeout", "read_uncommitted", "query_only", "page_size", "locking_mode"],
    fn pragma ->
      [row] = GenServer.call(owner, {:query, "PRAGMA #{pragma}", []})
      [value] = Map.values(row)
      {pragma, value}
    end
  )
end

readers =
  if Process.whereis(DB.ReadPool) do
    for {partition, pid, :worker, _} <- PartitionSupervisor.which_children(DB.ReadPool) do
      {:error, error} =
        GenServer.call(pid, {:query, "UPDATE accounts SET name=name", []})

      true = is_exception(error)
      %{partition: partition, readonly_verified: true, pragmas: pragmas.(pid)}
    end
  else
    []
  end

IO.puts(Jason.encode!(%{
  elixir: System.version(),
  otp: File.read!("/usr/local/lib/erlang/releases/29/OTP_VERSION") |> String.trim(),
  architecture: :erlang.system_info(:system_architecture) |> List.to_string(),
  emulator: :erlang.system_info(:emu_flavor),
  schedulers_online: System.schedulers_online(),
  schedulers_total: :erlang.system_info(:schedulers),
  erl_flags: System.get_env("ERL_FLAGS"),
  elixir_erl_options: System.get_env("ELIXIR_ERL_OPTIONS"),
  nofile: File.read!("/proc/self/limits") |> String.split("\n") |> Enum.find(&String.starts_with?(&1, "Max open files")),
  cpu_affinity: File.read!("/proc/self/status") |> String.split("\n") |> Enum.find(&String.starts_with?(&1, "Cpus_allowed_list:")),
  sqlite_version: DB.one("SELECT sqlite_version() AS version"),
  writer_pragmas: pragmas.(Process.whereis(DB)),
  readers: readers
}))
