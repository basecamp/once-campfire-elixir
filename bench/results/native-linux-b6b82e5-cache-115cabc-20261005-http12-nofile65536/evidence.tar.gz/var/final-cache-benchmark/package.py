"""Package immutable evidence and verify every payload member plus portable report reproduction."""
import hashlib
import json
import pathlib
import subprocess
import tarfile
import tempfile

META = pathlib.Path(__file__).resolve().parent
ROOT = META.parents[1]
RESULT = pathlib.Path('bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536')
DEST = pathlib.Path('/home/user/workspace/repo/.amp/in/artifacts')
ARCHIVE = DEST / 'linux-final-baseline-cache-http12-evidence.tar.gz'
MANIFEST = META / 'archive-files.sha256'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not ARCHIVE.exists(), 'Never replace an evidence archive'
assert not MANIFEST.exists(), 'Never replace an evidence manifest'
files = {p for folder in [ROOT / RESULT, META] for p in folder.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
files.update(ROOT / p for p in json.loads((META / 'harness-files.json').read_text()))
files.update(ROOT / p for p in [
    'lib/campfire/db.ex', 'lib/campfire/application.ex', 'lib/campfire/messages_view.ex',
    'lib/campfire/http_compression.ex', 'test/db_statement_cache_test.exs', 'test/messages_view_test.exs',
    'mix.exs', 'mix.lock', 'Dockerfile', 'bin/container-start', 'parity/results/verification.json',
])
assert all(p.is_file() for p in files)
assert not any(p.name.endswith('.env') or p.name == 'reference.env' for p in files)
hashes = {str(p.relative_to(ROOT)): sha(p) for p in sorted(files)}
MANIFEST.write_text(''.join(f'{digest}  {name}\n' for name, digest in hashes.items()))
with tarfile.open(ARCHIVE, 'w:gz', compresslevel=6) as archive:
    for path in sorted(files | {MANIFEST}):
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)

with tarfile.open(ARCHIVE) as archive:
    members = {m.name: m for m in archive.getmembers()}
    assert len(members) == len(files) + 1
    assert set(members) == set(hashes) | {str(MANIFEST.relative_to(ROOT))}
    for name, digest in hashes.items():
        assert hashlib.sha256(archive.extractfile(members[name]).read()).hexdigest() == digest, name
    assert archive.extractfile(members[str(MANIFEST.relative_to(ROOT))]).read() == MANIFEST.read_bytes()

with tempfile.TemporaryDirectory(prefix='campfire-final-report-') as temporary:
    extracted = pathlib.Path(temporary)
    with tarfile.open(ARCHIVE) as archive:
        # All members are exact relative paths generated above from first-party local files.
        assert all(not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
                   and m.isfile() for m in archive.getmembers())
        archive.extractall(extracted)
    subprocess.run(['sha256sum', '-c', str(MANIFEST.relative_to(ROOT))], cwd=extracted,
                   check=True, stdout=subprocess.DEVNULL)
    subprocess.run(['python3', 'bench/validate-results.py', 'check', str(RESULT)], cwd=extracted, check=True)
    report = subprocess.check_output(['python3', 'bench/report', str(RESULT)], cwd=extracted)
    assert report == (ROOT / RESULT / 'report.md').read_bytes()

checksum = sha(ARCHIVE)
ARCHIVE.with_suffix(ARCHIVE.suffix + '.sha256').write_text(f'{checksum}  {ARCHIVE.name}\n')
receipt = {
    'passed': True, 'archive': str(ARCHIVE), 'sha256': checksum, 'bytes': ARCHIVE.stat().st_size,
    'checksummed_payload_members': len(hashes), 'manifest_members': 1,
    'every_payload_hash_verified_against_archive': True,
    'extracted_sha256sum_and_schema2_validator_passed': True,
    'extracted_report_reproduced_byte_identically': True,
    'report_sha256': hashlib.sha256(report).hexdigest(),
    'temporary_extraction_removed': True,
}
(DEST / 'linux-final-baseline-cache-http12-package-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
