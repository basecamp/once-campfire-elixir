"""Real production-image Cable checks, never part of the final timing results."""
import importlib.util
import json
import pathlib
import resource
import shutil
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
META = ROOT / 'var/final-cache-benchmark'
PRIMARY = pathlib.Path('/home/user/workspace/repo')
spec = importlib.util.spec_from_file_location('retained_fixture_driver', PRIMARY / 'var/linux-diagnosis/run.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
d.OUT = META / 'cable-smoke'
d.OUT.mkdir(exist_ok=False)
d.WORK = META / 'cable-smoke-work'
d.NAME = 'campfire-final-cache-cable-smoke'
d.IMAGES['candidate'] = 'sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5'
scrape = None
sequence = 0
destination = None

def run(args):
    global sequence
    args = list(map(str, args))
    args = [str(ROOT / 'bench/validate.py') if x == str(PRIMARY / 'bench/validate.py') else x for x in args]
    if args[:3] == ['docker', 'run', '-d']: args[-1:-1] = ['-v', f'{META}:/final-checks:ro']
    logged = args.copy()
    for flag in ['--cookie', '--password', '--csrf']:
        if flag in logged: logged[logged.index(flag) + 1] = '<ephemeral fixture credential>'
    if len(logged) > 4 and logged[2] == 'preflight': logged[4] = '<ephemeral fixture cookie>'
    with (META / 'cable-smoke-commands.jsonl').open('a') as file:
        file.write(json.dumps({'at': time.time(), 'argv': logged}) + '\n')
    result = subprocess.run(args, capture_output=True, text=True)
    sequence += 1
    if 'cable' in args or result.returncode:
        d.save(destination / f'command-{sequence:03d}.json', {'argv': logged, 'exit': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode: raise RuntimeError(result.stderr + result.stdout)
    return result.stdout

def load(*args):
    global scrape
    value = json.loads(run(['taskset', '-c', d.LOADGEN, ROOT / 'target/bench/release/loadgen', *args]))
    if args[0] == 'scrape': scrape = value
    return value

d.run, d.load = run, load
resource.setrlimit(resource.RLIMIT_NOFILE, (65536, resource.getrlimit(resource.RLIMIT_NOFILE)[1]))
cases = []
for app in ['baseline', 'candidate']:
    destination = d.OUT / app
    destination.mkdir(exist_ok=False)
    try:
        _, cookie, labels = d.setup('baseline' if app == 'baseline' else 'stock', destination)
        runtime = json.loads(d.rpc('Code.eval_file("/final-checks/runtime.exs")'))
        identity = json.loads(d.rpc('Code.eval_file("/final-checks/identity.exs")'))
        d.save(destination / 'runtime-details.json', runtime)
        d.save(destination / 'identity-before.json', identity)
        assert identity['normal_online'] == identity['dirty_cpu'] == 4 and identity['normal_schedulers'] == 16
        assert identity['dirty_io'] == 10 and len(identity['readers']) == (0 if app == 'baseline' else 4)
        assert runtime['nofile'].split()[3:5] == ['65536', '65536']
        assert identity['erl_flags'] == (None if app == 'baseline' else '')
        for deflate in [0, 1]:
            value = load('cable', '--base', d.BASE, '--cookie', cookie, '--room', labels['rooms.watercooler'],
                '--csrf', scrape['csrf'], '--streams', ','.join(scrape['streams']), '--clients', 10,
                '--latency-msgs', 3, '--tput-secs', 1, '--posters', 1, '--deflate', deflate)
            d.save(destination / f'deflate-{deflate}.json', value)
            assert value['ready'] == value['clients'] == 10 and value['failed'] == 0
            paced, saturated = value['latency'], value['throughput']
            assert paced['post_attempts'] == paced['post_successes'] == paced['complete'] == paced['messages'] == 3
            assert saturated['post_attempts'] == saturated['posted'] == saturated['complete'] > 0
            assert paced['post_errors'] == saturated['post_errors'] == 0
            if deflate == 0: assert saturated['wire_mb_per_sec'] is None
            else: assert isinstance(saturated['wire_mb_per_sec'], (int, float)) and saturated['wire_mb_per_sec'] >= 0
            jobs = json.loads(run(['python3', ROOT / 'bench/job-state.py', 120]))
            d.save(destination / f'deflate-{deflate}-jobs.json', jobs)
            assert jobs['backend'] == 'redis_resque' and jobs['drained']
            cases.append({'app': app, 'deflate': deflate, 'complete': saturated['complete'],
                'wire_mb_per_sec': saturated['wire_mb_per_sec'], 'passed': True})
        final = json.loads(d.rpc('Code.eval_file("/final-checks/identity.exs")'))
        d.save(destination / 'identity-after.json', final)
        assert identity == final
    finally:
        logs = subprocess.run(['docker', 'logs', d.NAME], capture_output=True, text=True)
        (destination / 'container.log').write_text(logs.stdout + logs.stderr)
        subprocess.run(['docker', 'rm', '-f', d.NAME], capture_output=True)
        if d.WORK.exists(): shutil.rmtree(d.WORK)
receipt = {'passed': True, 'cases': cases, 'purpose': 'correctness smoke, not clean timing', 'default_runtime_both_images': True}
d.save(META / 'cable-smoke-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
