#!/usr/bin/env bash
# Disposable execution receipt; application and benchmark harness remain unchanged.
set -euo pipefail
ROOT=/home/user/workspace/benchmark-cache-final-linux
META=$ROOT/var/final-cache-benchmark
OUT=$ROOT/bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536
cd "$ROOT"
test "$(git rev-parse HEAD)" = 115cabc787bd3ed7bb6ccba5a6d9d6a4fc7e5948
git diff --exit-code HEAD -- . ':!parity'
test ! -e "$OUT"
test -z "$(docker ps -q)"
python3 bench/validate.py ledger
test "$(python3 bench/validate.py digest)" = d95a406a33915790b632420d97840c96d76e4bd8a5e7595c58bdf2d84bf58efe
python3 /home/user/workspace/repo/var/linux-diagnosis/audit.py > "$META/preservation-before.json"
python3 "$META/check-preservation.py" > "$META/extended-preservation-before.json"
snapshot() {
  date -Is
  uname -a
  lscpu -e=CPU,CORE,SOCKET,ONLINE
  free -b
  cat /proc/loadavg
  cat /proc/stat
  for file in cpu.max cpu.stat memory.max memory.current memory.swap.max; do
    printf '\n%s\n' "$file"
    cat "/sys/fs/cgroup/amp.slice/amp-workload.slice/$file"
  done
  docker ps --format '{{.Names}} {{.Image}}'
  docker image inspect \
    sha256:7cb5658090eee9c77c4d19572766434bb4a2b6654b80334bb8f43df02f922182 \
    sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5 \
    rust@sha256:4cd829461bd5c4d511c32e269da9cb8929223b666519d8004e35fc8d1d771ab7 \
    --format '{{.Id}} {{.Os}}/{{.Architecture}} {{json .RepoDigests}}'
}
snapshot > "$META/host-before.txt"
git status --short > "$META/git-status-before.txt"
date -Is > "$META/started-at.txt"
date +%s.%N > "$META/started-epoch.txt"
set +e
SERVER_CPUS=0,2,4,6 LOADGEN_CPUS=8,10,12,14 PROCMEM_CPUS=15 \
HTTP_SECS=12 HTTP_CONCS='1 16 64' \
CABLE_CLIENTS='100 500 1000' CABLE_TPUT_SECS=15 CABLE_POSTERS=4 UPLOAD_REPS=5 \
NOFILE=65536 SEED=/home/user/workspace/repo/var/linux-benchmark-setup/seed/default \
BASELINE_SHA=b6b82e50a653c4060136bb04e805eb78fd76ba10 \
CANDIDATE_SHA='6f06e50f2ec5dae69331c2c5dd033b4ac8849580+verified-cache-overlay; app-source-equivalent-to-115cabc787bd3ed7bb6ccba5a6d9d6a4fc7e5948; not-rebuilt-from-115cabc' \
BASELINE_IMAGE=sha256:7cb5658090eee9c77c4d19572766434bb4a2b6654b80334bb8f43df02f922182 \
CANDIDATE_IMAGE=sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5 \
LOADGEN_BUILD_IMAGE=rust@sha256:4cd829461bd5c4d511c32e269da9cb8929223b666519d8004e35fc8d1d771ab7 \
bench/run --apps baseline,candidate --reps 4 --out "$OUT" 2>&1 | tee "$META/run.log"
status=${PIPESTATUS[0]}
set -e
printf '%s\n' "$status" > "$META/exit-status.txt"
date +%s.%N > "$META/finished-epoch.txt"
date -Is > "$META/finished-at.txt"
snapshot > "$META/host-after.txt"
git status --short > "$META/git-status-after.txt"
python3 /home/user/workspace/repo/var/linux-diagnosis/audit.py > "$META/preservation-after.json"
python3 "$META/check-preservation.py" > "$META/extended-preservation-after.json"
python3 bench/validate.py ledger
python3 bench/validate.py digest > "$META/source-digest-after.txt"
git diff --exit-code HEAD -- . ':!parity'
exit "$status"
