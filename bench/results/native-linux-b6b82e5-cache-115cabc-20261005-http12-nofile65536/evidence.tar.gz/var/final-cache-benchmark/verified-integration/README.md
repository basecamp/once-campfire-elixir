# Native amd64 statement-cache integration verification

Diagnostic integration only. No commit, push, PR or runtime default change.

Base checkout is 6f06e50f2ec5dae69331c2c5dd033b4ac8849580 plus exactly three
uncommitted overlay paths; the base revision alone is not the source identity.
`overlay-provenance.json` records both supplied archives and all source hashes.
The original archive's AppleDouble entries were never extracted. The clean
replacement was byte-verified, not reapplied; no gate was restarted for metadata.

Source digest: d95a406a33915790b632420d97840c96d76e4bd8a5e7595c58bdf2d84bf58efe.
Native production image: sha256:57ec8cf3ec3539e3a5b6e5b41ef1010862eebff5f36942182b52bfab556ac6f5.
Build metadata: GIT_REVISION=6f06e50-overlay-83343b42,
APP_VERSION=statement-cache-integration. No runtime module overlays were used.
The separate parity-release image is recorded in `parity-release-image.txt`.
The preexisting release tag was restored; the new images remain available.

Executed commands are in strict.sh/strict-commands.txt, parity.sh,
scheduler-tests.sh and production-check.sh. All exited zero. The audit checks
the source digest, exact overlay bytes, all 65 gate results, 1941 unit tests,
36 toolkit tests, 33 targeted tests, strict format/compile/Credo/Dialyzer
(0 errors), and production checks. Explicit scheduler DB/cache tests: +S4
15 passed; +S1 12 passed and three genuine pool-only skips.

Production checks used four online normal schedulers (16 configured), four
readonly readers, dirty IO10, nofile65536 and no ERL_FLAGS override. Runtime
Elixir1.20.4/OTP29.1.1/JIT/Linux amd64. All reader PRAGMAs were captured;
readonly is tested by rejected writes, not query_only. PRAGMA busy_timeout=0
is preserved, not interpreted as absence of Exqlite's custom busy handler.
Three mixed-write rounds proved transaction-local reads, reader progress
during uncommitted writes and post-commit visibility. Killing one reader
recovered the route in 2103us in this check; writer, pool and other readers
remained unchanged. This is not a guarantee for interrupted in-flight queries.

All prior diagnostic manifests, the 309-file frozen full benchmark, frozen
source digest and original seed evidence passed preservation checks. No
integrated performance claim is made by this correctness receipt. A separate
authorized bounded four-arm selection diagnostic follows this archive.
