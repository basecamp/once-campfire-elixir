#!/bin/bash
set -euo pipefail
OUT=var/verification-statement-cache
date -Is > "$OUT/parity-started.txt"
bin/parity-services start > "$OUT/services-start.log" 2>&1
set +e
bin/verify-parity > "$OUT/parity.log" 2>&1
status=$?
set -e
echo "$status" > "$OUT/parity-exit.txt"
date -Is > "$OUT/parity-finished.txt"
cp parity/results/verification.json "$OUT/verification.json"
if [ "$status" = 0 ]; then
  python3 bench/validate.py ledger > "$OUT/ledger.log" 2>&1
fi
bin/parity-services stop > "$OUT/services-stop.log" 2>&1
docker rm -f campfire-elixir-release >> "$OUT/services-stop.log" 2>&1
tail -30 "$OUT/parity.log"
exit "$status"
