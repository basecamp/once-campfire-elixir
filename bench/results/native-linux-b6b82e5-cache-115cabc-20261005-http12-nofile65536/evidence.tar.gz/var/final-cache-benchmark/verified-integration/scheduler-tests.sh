#!/bin/bash
set -euo pipefail
OUT=var/verification-statement-cache
for schedulers in 4 1; do
  date -Is > "$OUT/schedulers-$schedulers-started.txt"
  set +e
  docker run --rm --network host --user "$(id -u):$(id -g)" \
    -e HOME=/app -e TMPDIR=/app/var/tmp -e HEX_HOME=/app/.hex -e MIX_HOME=/app/.mix \
    -e EXQLITE_USE_SYSTEM=1 -e CAMPFIRE_NO_SERVER=1 -e CAMPFIRE_JOBS_ADAPTER=disabled \
    -e DATABASE_PATH=/app/var/test.sqlite3 -e "ERL_FLAGS=+S $schedulers" \
    -v "$PWD:/app" -w /app campfire-elixir:toolchain \
    mix test --warnings-as-errors test/db_test.exs test/db_statement_cache_test.exs \
    > "$OUT/schedulers-$schedulers.log" 2>&1
  status=$?
  set -e
  echo "$status" > "$OUT/schedulers-$schedulers-exit.txt"
  date -Is > "$OUT/schedulers-$schedulers-finished.txt"
  cat "$OUT/schedulers-$schedulers.log"
  test "$status" = 0
done
