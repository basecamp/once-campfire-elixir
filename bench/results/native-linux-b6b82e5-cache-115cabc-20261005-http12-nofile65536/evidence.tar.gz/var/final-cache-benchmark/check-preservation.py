"""Check frozen source, seeds, archives and every retained raw diagnostic manifest."""
import hashlib
import json
import pathlib

META = pathlib.Path(__file__).resolve().parent
ROOT = META.parents[1]
PRIMARY = pathlib.Path('/home/user/workspace/repo')
OLD = pathlib.Path('/home/user/workspace/verify-readers-linux')


def sha(path):
    with path.open('rb') as file:
        digest = hashlib.sha256()
        while block := file.read(1024 * 1024):
            digest.update(block)
        return digest.hexdigest()


def check_manifest(manifest, root):
    count = 0
    for line in manifest.read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert sha(root / name) == expected, str(root / name)
        count += 1
    return count


counts = {}
manifests = [(p, PRIMARY) for p in sorted((PRIMARY / 'var').glob('linux-*/raw-files.sha256'))]
manifests += [(PRIMARY / 'var/linux-cache-selection-corrected/archive-files.sha256', PRIMARY),
              (OLD / 'var/benchmark-6f06e50/results.sha256', OLD)]
manifests += [(META / name, ROOT) for name in ['prior-archives.sha256', 'seed-before.sha256', 'loadgen.sha256']]
for manifest, root in manifests:
    counts[str(manifest)] = check_manifest(manifest, root)
for filename in ['canonical-app-files.json', 'harness-files.json']:
    files = json.loads((META / filename).read_text())
    for name, expected in files.items():
        assert sha(ROOT / name) == expected, name
    counts[filename] = len(files)
print(json.dumps({'passed': True, 'checked_manifest_file_counts': counts}, indent=2))
