"""Derive comparison tables without changing the frozen report or measured records."""
import csv
import json
import pathlib
import statistics

META = pathlib.Path(__file__).resolve().parent
ROOT = META.parents[1]
OUT = ROOT / 'bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536'
receipt = json.loads((META / 'receipt.json').read_text())
http = receipt['http_medians_and_ranges']
rows = {(r['route'], r['concurrency'], r['metric']): r for r in http}
samples = {app: [json.loads((OUT / f'{app}-{i}.json').read_text()) for i in range(1, 5)]
           for app in ['baseline', 'candidate']}
preflights = [json.loads((OUT / f'{app}-{i}-validation.json').read_text())
              for app in samples for i in range(1, 5)]
decoded_sizes = {}
for route in preflights[0]['responses']:
    sizes = {p['responses'][route]['body_bytes'] for p in preflights}
    assert len(sizes) == 1, (route, sizes)
    decoded_sizes[route] = sizes.pop()
(META / 'decoded-size-audit.json').write_text(json.dumps({
    'passed': True, 'preflights': 8, 'decoded_sizes': decoded_sizes,
    'limitation': 'Equal decoded lengths and populated preflight checks are not byte-equality proof; response bodies are not retained, only their lengths and hashes.'
}, indent=2) + '\n')


def spread(values, digits=1):
    return f'{statistics.median(values):,.{digits}f} [{min(values):,.{digits}f}–{max(values):,.{digits}f}]'


def change(baseline, candidate):
    return 100 * (statistics.median(candidate) / statistics.median(baseline) - 1)


def paired(baseline, candidate):
    return [100 * (c / b - 1) for b, c in zip(baseline, candidate)]


lines = [
    '# Four-round native Linux comparison: complete, with tail regressions', '',
    'Baseline is untouched upstream; candidate is the verified reader/cache application. This is not an isolated attribution of all gains to statement caching.', '',
    '## HTTP throughput and paired ranges', '',
    'Each arm cell is median [min–max] over four rounds. Paired changes compare candidate/baseline within the same round; these ranges are descriptive, not confidence intervals. p99 is the median of four cell p99s, not a pooled percentile. Positive CPU or latency changes are worse.', '',
    '**CPU limitation:** ' + receipt['cpu_counter_limitation'], '',
    '| Route | c | Baseline req/s | Candidate req/s | Median change | Paired changes | p99 median change | CPU/success median change |',
    '|---|---:|---:|---:|---:|---:|---:|---:|',
]
for r in http:
    if r['metric'] != 'rps':
        continue
    tail = rows[r['route'], r['concurrency'], 'p99_ms']
    cpu = rows[r['route'], r['concurrency'], 'cpu_us_per_success']
    lines.append(f"| {r['route']} | {r['concurrency']} | {spread(r['baseline_values'])} | {spread(r['candidate_values'])} | {r['candidate_change_percent']:+.1f}% | {r['paired_min_percent']:+.1f} to {r['paired_max_percent']:+.1f}% | {tail['candidate_change_percent']:+.1f}% | {cpu['candidate_change_percent']:+.1f}% |")

lines += ['', '## High-concurrency rendering tails remain unresolved', '',
          '| Route | c | Baseline p99 ms | Candidate p99 ms | Paired p99 change | Baseline CPU µs/success | Candidate CPU µs/success |',
          '|---|---:|---:|---:|---:|---:|---:|']
for route in ['room_show', 'messages_page']:
    for conc in [16, 64]:
        t, c = rows[route, conc, 'p99_ms'], rows[route, conc, 'cpu_us_per_success']
        lines.append(f"| {route} | {conc} | {spread(t['baseline_values'], 3)} | {spread(t['candidate_values'], 3)} | {t['paired_min_percent']:+.1f} to {t['paired_max_percent']:+.1f}% | {spread(c['baseline_values'])} | {spread(c['candidate_values'])} |")

lines += ['', '## HTTP response-body wire bytes', '',
          'These are integer-truncated mean body bytes from each load-generator cell, with gzip requested. Headers/framing/TCP/TLS are excluded. Full per-cell numbers are in http-cells.csv; the table covers all 12 cells per route and arm. This is not independently decoded per-response content evidence.', '',
          'All eight retained preflights have equal decoded lengths for each route, including search (165,534 bytes), room (463,753 bytes), messages (430,965 bytes) and sidebar (31,427 bytes). Search wire bodies are about 2.6% smaller in the candidate; no compression setting was changed in this run. The capture does not establish the cause or normalized byte equality of the differing body hashes.', '',
          '| Route | Baseline min–max bytes | Candidate min–max bytes |', '|---|---:|---:|']
for route in dict.fromkeys(r['route'] for r in http):
    vals = {app: [v for r in http if r['route'] == route and r['metric'] == 'avg_bytes' for v in r[f'{app}_values']]
            for app in samples}
    lines.append(f"| {route} | {min(vals['baseline']):,}–{max(vals['baseline']):,} | {min(vals['candidate']):,}–{max(vals['candidate']):,} |")

other = []
for clients in [100, 500, 1000]:
    for metric, keys in [
        ('complete fanouts/s', ['throughput', 'delivered_msgs_per_sec']),
        ('paced all-client p50 ms', ['latency', 'all_clients', 'p50_ms']),
        ('paced all-client p99 ms', ['latency', 'all_clients', 'p99_ms']),
        ('saturated all-client p50 ms', ['throughput', 'all_clients', 'p50_ms']),
        ('saturated all-client p99 ms', ['throughput', 'all_clients', 'p99_ms']),
        ('connect all seconds', ['connect_secs']),
    ]:
        values = {}
        for app in samples:
            values[app] = []
            for sample in samples[app]:
                value = next(c for c in sample['cable'] if c['clients'] == clients)
                for key in keys:
                    value = value[key]
                values[app].append(value)
        deltas = paired(values['baseline'], values['candidate'])
        other.append({'workload': f'Cable{clients}', 'metric': metric, **values,
                      'median_change_percent': change(values['baseline'], values['candidate']),
                      'paired_changes_percent': deltas})
for metric in ['idle_current_mb', 'idle_anon_mb', 'peak_current_mb', 'peak_anon_mb', 'cgroup_peak_mb']:
    values = {app: [s['memory'][metric] for s in samples[app]] for app in samples}
    other.append({'workload': 'whole arm-run', 'metric': metric, **values,
                  'median_change_percent': change(values['baseline'], values['candidate']),
                  'paired_changes_percent': paired(values['baseline'], values['candidate'])})
for metric in ['cold_start_ms', 'upload_total_ms']:
    values = {app: [s['cold_start_ms'] if metric == 'cold_start_ms' else s['upload']['median_total_ms'] for s in samples[app]] for app in samples}
    other.append({'workload': 'startup' if metric == 'cold_start_ms' else 'upload5', 'metric': metric, **values,
                  'median_change_percent': change(values['baseline'], values['candidate']),
                  'paired_changes_percent': paired(values['baseline'], values['candidate'])})
lines += ['', '## Cable, memory, startup and uploads', '',
          'Cable wire rate is null/unmeasured in every measured case. The separate deflate smoke demonstrates measured nonzero wire rates but is not part of these timings. Memory units are MiB; whole arm-run cgroup peaks include all three suites, not a single HTTP route.', '',
          '| Workload | Metric | Baseline median [min–max] | Candidate median [min–max] | Median change | Paired changes |',
          '|---|---|---:|---:|---:|---:|']
for r in other:
    p = r['paired_changes_percent']
    lines.append(f"| {r['workload']} | {r['metric']} | {spread(r['baseline'], 3)} | {spread(r['candidate'], 3)} | {r['median_change_percent']:+.1f}% | {min(p):+.1f} to {max(p):+.1f}% |")
(META / 'comparison.md').write_text('\n'.join(lines) + '\n')
(META / 'other-metrics.json').write_text(json.dumps(other, indent=2) + '\n')
with (META / 'other-metrics.csv').open('w') as file:
    writer = csv.DictWriter(file, fieldnames=list(other[0]))
    writer.writeheader()
    writer.writerows(other)
print(f'Wrote 24 HTTP comparison cells and {len(other)} other metric rows.')
