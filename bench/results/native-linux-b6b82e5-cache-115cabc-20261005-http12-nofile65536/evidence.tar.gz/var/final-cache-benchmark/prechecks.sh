#!/bin/bash
set -euo pipefail
META=var/final-cache-benchmark
run() {
  name=$1; shift
  printf '%q ' "$@" >> "$META/precheck-commands.txt"; printf '\n' >> "$META/precheck-commands.txt"
  date -Is > "$META/$name-started.txt"
  set +e
  "$@" > "$META/$name.log" 2>&1
  status=$?
  set -e
  echo "$status" > "$META/$name-exit.txt"
  date -Is > "$META/$name-finished.txt"
  cat "$META/$name.log"
  return "$status"
}
run toolkit python3 -m unittest discover -s tools/rails-to-elixir/tests
run rust docker run --rm --user "$(id -u):$(id -g)" \
  -e CARGO_HOME=/cargo -e CARGO_TARGET_DIR=/app/target/bench \
  -v /tmp/campfire-bench-cargo:/cargo -v "$PWD:/app" -w /app/bench/loadgen \
  rust@sha256:4cd829461bd5c4d511c32e269da9cb8929223b666519d8004e35fc8d1d771ab7 \
  sh -c 'rustc --version; cargo --version; cargo test --locked && cargo check --locked && cargo build --release --locked'
sha256sum target/bench/release/loadgen > "$META/loadgen.sha256"
