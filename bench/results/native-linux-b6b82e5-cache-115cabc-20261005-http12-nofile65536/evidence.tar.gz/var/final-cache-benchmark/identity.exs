readers =
  if Process.whereis(Campfire.DB.ReadPool) do
    for {id, pid, :worker, _} <- PartitionSupervisor.which_children(Campfire.DB.ReadPool) do
      state = :sys.get_state(pid)
      info =
        if is_reference(state) do
          %{state: "raw_connection_no_statement_cache"}
        else
          true = state.__struct__ == Campfire.DB.Reader
          64 = state.limit
          true = map_size(state.statements) <= 64
          %{state: "bounded_statement_cache", limit: state.limit}
        end
      Map.merge(info, %{id: id, pid: inspect(pid)})
    end
  else
    []
  end

writer = Process.whereis(Campfire.DB)
true = is_reference(:sys.get_state(writer))
modules = for mod <- [Campfire.DB, Campfire.Application, Campfire.MessagesView, Campfire.HttpCompression, Campfire.FragmentCache], into: %{} do
  {:module, ^mod} = Code.ensure_loaded(mod)
  {^mod, binary, _} = :code.get_object_code(mod)
  {Atom.to_string(mod), %{md5: Base.encode16(mod.module_info(:md5), case: :lower),
    beam_sha256: Base.encode16(:crypto.hash(:sha256, binary), case: :lower)}}
end

IO.puts(Jason.encode!(%{os_pid: System.pid(), writer: inspect(writer), readers: readers,
  pool: inspect(Process.whereis(Campfire.DB.ReadPool)), modules: modules,
  normal_schedulers: :erlang.system_info(:schedulers), normal_online: System.schedulers_online(),
  dirty_cpu: :erlang.system_info(:dirty_cpu_schedulers_online),
  dirty_io: :erlang.system_info(:dirty_io_schedulers), erl_flags: System.get_env("ERL_FLAGS"),
  architecture: :erlang.system_info(:system_architecture) |> List.to_string(),
  emulator: :erlang.system_info(:emu_flavor)}))
