#!/usr/bin/env python3
"""Read-only companion audit; writes derived receipts outside measured results."""
import csv
import hashlib
import json
import pathlib
import re
import statistics
import subprocess

META = pathlib.Path(__file__).resolve().parent
ROOT = META.parents[1]
OUT = ROOT / "bench/results/native-linux-b6b82e5-cache-115cabc-20261005-http12-nofile65536"
SOURCE = "115cabc787bd3ed7bb6ccba5a6d9d6a4fc7e5948"
DIGEST = "d95a406a33915790b632420d97840c96d76e4bd8a5e7595c58bdf2d84bf58efe"
ROUTES = ["room_show", "messages_page", "sidebar", "search", "avatar", "static_css", "up", "post_message"]
CONCS = [1, 16, 64]
CLIENTS = [100, 500, 1000]
APPS = ["baseline", "candidate"]
CPU_LIMIT = ("Derived CPU/success is retained, but raw per-cell cgroup before/after counter pairs "
             "are not. Raw/enriched load-generator records can be compared; CPU deltas cannot "
             "be independently reconstructed from retained counters.")


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


assert command("git", "rev-parse", "HEAD") == SOURCE
assert command("python3", "bench/validate.py", "digest") == DIGEST
assert command("python3", "bench/validate.py", "ledger") == ""
assert command("python3", "bench/validate-results.py", "check", str(OUT)) == ""
assert command("docker", "ps", "-q") == ""
for path in command("git", "diff", "--name-only", "HEAD").splitlines():
    assert path.startswith("parity/results/") or (path.startswith("parity/") and path.endswith(".log")), path
ledger = read(ROOT / "parity/results/verification.json")
assert all(ledger[key] is True for key in ["passed", "complete_run", "source_unchanged"])
assert ledger["source_digest"] == DIGEST
assert len(ledger["gates"]) == 65 and all(g["passed"] and g["exit_code"] == 0 for g in ledger["gates"])
manifest = read(OUT / "manifest.json")
assert manifest["schema_version"] == 2 and manifest["complete"] and manifest["status"] == "complete"
assert manifest["expected"] == {
    "apps": APPS, "reps": 4, "suites": ["http", "cable", "upload"],
    "http_routes": ROUTES, "http_concs": CONCS, "cable_clients": CLIENTS, "upload_reps": 5,
}
assert (META / "exit-status.txt").read_text().strip() == "0"
assert (META / "report-reproduced.md").read_bytes() == (OUT / "report.md").read_bytes()

provenance = read(META / "provenance.json")
assert provenance["passed"] and provenance["canonical_files_equal"] == 689
assert provenance["application_digest"] == DIGEST and provenance["harness_revision"] == SOURCE
assert provenance["reused_parity_ledger_sha256"] == sha(ROOT / "parity/results/verification.json")
for app in APPS:
    image = provenance["images"][app]
    inspected = json.loads(command("docker", "image", "inspect", image["Id"]))[0]
    assert all(inspected[key] == value for key, value in image.items())
    smoke = META / "cable-smoke" / app
    before, after = read(smoke / "identity-before.json"), read(smoke / "identity-after.json")
    assert before == after
    assert (before["normal_schedulers"], before["normal_online"], before["dirty_cpu"], before["dirty_io"]) == (16, 4, 4, 10)
    runtime = read(smoke / "runtime-details.json")
    assert (runtime["elixir"], runtime["otp"], runtime["architecture"]) == ("1.20.4", "29.1.1", "x86_64-pc-linux-gnu")
    assert "65536                65536" in runtime["nofile"]
    assert runtime["cpu_affinity"].split()[-1] == "0,2,4,6"
    assert len(before["readers"]) == (4 if app == "candidate" else 0)
    assert all(reader["limit"] == 64 and reader["state"] == "bounded_statement_cache" for reader in before["readers"])
    for deflate in [0, 1]:
        smoke_row = read(smoke / f"deflate-{deflate}.json")
        wire = smoke_row["throughput"]["wire_mb_per_sec"]
        assert (wire is None) if deflate == 0 else wire > 0
assert read(META / "cable-smoke-receipt.json")["passed"]
assert read(META / "extended-preservation-before.json") == read(META / "extended-preservation-after.json")

counts = dict(runs=0, http_samples=0, http_successes=0, cable_cases=0,
              cable_paced_attempts=0, cable_saturated_attempts=0,
              cable_saturated_completed=0, uploads=0)
raw_paths = set()
samples = {}
job_quiet = {}
http_cells = []
for app in APPS:
    samples[app] = []
    for rep in range(1, 5):
        name = f"{app}-{rep}"
        sample = read(OUT / f"{name}.json")
        assert sample["app"] == app and sample["rep"] == rep and sample["sample_complete"]
        preflight = read(OUT / f"{name}-validation.json")
        assert preflight["passed"] and preflight["populated_fixture_and_integrity"]
        assert all(row["status"] == 200 and row["body_bytes"] > 0 for row in preflight["responses"].values())
        rows = {(row["route"], row["conc"]): row for row in sample["http"]}
        assert len(rows) == len(sample["http"]) == 24
        assert set(rows) == {(route, conc) for route in ROUTES for conc in CONCS}
        for (route, conc), row in rows.items():
            path = OUT / "raw" / f"{name}-http-{route}-c{conc}.json"
            raw_paths.add(path)
            raw = read(path)
            assert raw == {k: v for k, v in row.items() if k not in {"route", "cpu_us_per_success"}}
            assert raw["ok"] > 0 and raw["errors"] == raw["invalid_responses"] == 0
            assert raw["statuses"] == {"200": raw["ok"]} and raw["latency"]["n"] == raw["ok"]
            assert raw["secs"] >= 12 and row["cpu_us_per_success"] > 0
            assert raw["avg_bytes"] > 0 and raw["gzip"]
            # Duration is rounded to 0.01s and rate to 0.1 requests/s by the frozen loadgen.
            assert raw["ok"] / (raw["secs"] + 0.005) - 0.051 <= raw["rps"] <= raw["ok"] / (raw["secs"] - 0.005) + 0.051
            latency = raw["latency"]
            assert 0 < latency["p50_ms"] <= latency["p90_ms"] <= latency["p99_ms"] <= latency["max_ms"]
            http_cells.append({"app": app, "rep": rep, "route": route, "concurrency": conc,
                               "successes": raw["ok"], "secs": raw["secs"], "rps": raw["rps"],
                               "p50_ms": latency["p50_ms"], "p99_ms": latency["p99_ms"],
                               "cpu_us_per_success": row["cpu_us_per_success"],
                               "avg_wire_body_bytes": raw["avg_bytes"], "errors": 0})
            counts["http_samples"] += 1
            counts["http_successes"] += raw["ok"]
        assert sorted(row["clients"] for row in sample["cable"]) == CLIENTS
        for row in sample["cable"]:
            path = OUT / "raw" / f"{name}-cable-{row['clients']}.json"
            raw_paths.add(path)
            assert read(path) == {k: v for k, v in row.items() if k != "process_memory"}
            assert row["ready"] == row["clients"] and row["failed"] == 0
            paced, saturated = row["latency"], row["throughput"]
            assert paced["post_attempts"] == paced["post_successes"] == paced["complete"] == paced["messages"] == 30
            assert paced["post_errors"] == saturated["post_errors"] == 0
            assert saturated["post_attempts"] == saturated["posted"] == saturated["complete"] > 0
            assert saturated["wire_mb_per_sec"] is None
            for phase in [paced, saturated]:
                assert phase["all_clients"]["n"] == phase["complete"]
                assert phase["per_client"]["n"] == phase["complete"] * row["clients"]
            counts["cable_cases"] += 1
            counts["cable_paced_attempts"] += paced["post_attempts"]
            counts["cable_saturated_attempts"] += saturated["post_attempts"]
            counts["cable_saturated_completed"] += saturated["complete"]
        path = OUT / "raw" / f"{name}-upload.json"
        raw_paths.add(path)
        assert read(path) == sample["upload"]
        assert len(sample["upload"]["runs"]) == 5
        assert all(r["post_status"] == r["thumb_status"] == 200 and r["thumb_bytes"] > 100 and "error" not in r for r in sample["upload"]["runs"])
        jobs = read(OUT / f"{name}-jobs.json")
        assert jobs["drained"] and jobs["backend"] == "redis_resque"
        quiet = []
        for observation in reversed(jobs["observations"]):
            if any(observation[k] != 0 for k in ["queued", "active", "failed"]):
                break
            quiet.append(observation)
        assert len(quiet) >= 3 and quiet[0]["at"] - quiet[-1]["at"] >= 1
        job_quiet[name] = {"observations": len(quiet), "seconds": quiet[0]["at"] - quiet[-1]["at"]}
        counts["runs"] += 1
        counts["uploads"] += 5
        samples[app].append(sample)
assert raw_paths == set((OUT / "raw").iterdir()) and len(raw_paths) == 224
assert counts == read(OUT / "audit.json")["counts"]

log = (META / "run.log").read_text()
order = re.findall(r"\[\d\d:\d\d:\d\d\] (baseline|candidate) rep ([1-4]): starting", log)
expected_order = [(app, str(rep)) for rep in range(1, 5) for app in (APPS if rep % 2 else list(reversed(APPS)))]
assert order == expected_order
quiet_waits = [(float(load), int(wait)) for load, wait in re.findall(r"load before run: ([0-9.]+) [0-9.]+ [0-9.]+ \(waited (\d+)s\)", log)]
assert len(quiet_waits) == 8 and all(load < 1.5 and wait <= 900 for load, wait in quiet_waits)
for (app, rep), (load, _wait) in zip(order, quiet_waits):
    assert float(samples[app][int(rep) - 1]["loadavg_start"].split()[0]) == load
assert "Finished `release` profile [optimized]" in log
env = (OUT / "env.txt").read_text()
for expected in ["HTTP_SECS=12", "server cpus: 0,2,4,6", "loadgen cpus: 8,10,12,14",
                 "server_nofile=65536 loadgen_nofile=65536", f"benchmark source: {SOURCE}",
                 f"elixir source digest: {DIGEST}", "not-rebuilt-from-115cabc"]:
    assert expected in env
assert "bench dirty: 1 files" in env  # The newly created untracked result directory, not a harness edit.
assert command("git", "diff", "--name-only", "HEAD", "--", "bench") == ""
elapsed = float((META / "finished-epoch.txt").read_text()) - float((META / "started-epoch.txt").read_text())

hosts = [(META / f"host-{phase}.txt").read_text() for phase in ["before", "after"]]
cpu = [{row[0]: [int(n) for n in row[1:]] for line in host.splitlines() if re.match(r"cpu\d+ ", line) for row in [line.split()]} for host in hosts]
steal = {}
for i in [0, 2, 4, 6, 8, 10, 12, 14]:
    key = f"cpu{i}"
    delta = [end - start for start, end in zip(cpu[0][key], cpu[1][key])]
    steal[key] = 100 * delta[7] / sum(delta[:8])
assert all("nr_throttled 0\n" in host and "throttled_usec 0\n" in host for host in hosts)

http_summary = []
for route in ROUTES:
    for conc in CONCS:
        for metric in ["rps", "p50_ms", "p99_ms", "cpu_us_per_success", "avg_bytes"]:
            row = {"route": route, "concurrency": conc, "metric": metric}
            rounds = {}
            for app in APPS:
                values = [r["latency"][metric] if metric in {"p50_ms", "p99_ms"} else r[metric] for sample in samples[app] for r in sample["http"] if r["route"] == route and r["conc"] == conc]
                assert len(values) == 4
                rounds[app] = values
                row[f"{app}_values"] = values
                row.update({f"{app}_median": statistics.median(values), f"{app}_min": min(values), f"{app}_max": max(values)})
            row["candidate_change_percent"] = 100 * (row["candidate_median"] / row["baseline_median"] - 1)
            paired = [100 * (c / b - 1) for b, c in zip(rounds["baseline"], rounds["candidate"])]
            row.update(paired_changes_percent=paired, paired_min_percent=min(paired), paired_max_percent=max(paired))
            http_summary.append(row)
with (META / "http-summary.csv").open("w") as file:
    writer = csv.DictWriter(file, fieldnames=list(http_summary[0]))
    writer.writeheader()
    writer.writerows(http_summary)
with (META / "http-cells.csv").open("w") as file:
    writer = csv.DictWriter(file, fieldnames=list(http_cells[0]))
    writer.writeheader()
    writer.writerows(http_cells)
preservation = read(META / "preservation-after.json")
assert preservation["passed"] and preservation["published_files_byte_identical"] == 88 and preservation["seed_files_byte_identical"] == 18
receipt = {
    "passed": True, "source_revision": SOURCE, "source_digest": DIGEST,
    "runtime_build_provenance": provenance["runtime_build_provenance"],
    "images": provenance["images"],
    "application_and_harness_unchanged": True, "complete_parity_gates": 65,
    "counts": counts, "all_http_and_cable_errors": 0, "raw_files": len(raw_paths),
    "order": order, "quiet_waits": quiet_waits, "job_quiet_suffix": job_quiet,
    "elapsed_seconds_including_quiet_waits_and_build": elapsed,
    "whole_run_cpu_steal_percent_including_quiet_waits": steal,
    "workload_cgroup_throttling_events": 0, "report_reproduced_byte_identically": True,
    "report_sha256": sha(OUT / "report.md"), "original_published_files_byte_identical": 88,
    "seed_files_byte_identical": 18, "running_containers": 0,
    "attempts": 1, "superseded_or_excluded_runs": 0,
    "cpu_counter_limitation": CPU_LIMIT,
    "per_response_validation": "HTTP status200/nonempty body for every response; decoded populated content checked by per-arm preflight, not independently decoded for every timed response",
    "cable_wire_rate": "null for all24 measured non-deflate cases; unmeasured, not zero",
    "http_wire_size": "avg_bytes is mean response-body bytes on wire (gzip where served), excludes HTTP framing/headers; integer truncated by loadgen",
    "memory_limitation": "Peak memory is whole arm-run (HTTP/Cable/uploads), not per-route; process phase samples exclude kernel/socket memory",
    "runtime_probe_scope": "Separate pre-timing fresh-container smoke under same image/fixture/env/cpuset/nofile; no probes or runtime overlays during timing",
    "http_medians_and_ranges": http_summary,
}
(META / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
with (META / "results.sha256").open("w") as file:
    for path in sorted(OUT.rglob("*")):
        if path.is_file():
            file.write(f"{sha(path)}  {path.relative_to(ROOT)}\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "http_medians_and_ranges"}, indent=2))
