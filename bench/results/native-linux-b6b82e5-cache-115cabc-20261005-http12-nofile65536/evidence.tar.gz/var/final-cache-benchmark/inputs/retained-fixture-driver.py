#!/usr/bin/env python3
"""Disposable native diagnosis; never modify published runs or the seed."""
import argparse, collections, importlib.util, json, os, pathlib, resource, shutil, socket, sqlite3, subprocess, time, urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = ROOT / 'bench/results/native-linux-diagnosis-7c1ed67-20261005'
SEED = ROOT / 'var/linux-benchmark-setup/seed/default'
WORK = ROOT / 'var/linux-diagnosis/work'
NAME = 'campfire-linux-diagnosis'
PORT = 47140
BASE = f'http://127.0.0.1:{PORT}'
SERVER = '0,2,4,6'
LOADGEN = '8,10,12,14'
IMAGES = {'baseline': 'sha256:7cb5658090eee9c77c4d19572766434bb4a2b6654b80334bb8f43df02f922182', 'candidate': 'sha256:3cab19b9a0cc8416e94c9e91585eb4036a190d68a013df98726cbfb34fc344bc'}
spec = importlib.util.spec_from_file_location('benchlib', ROOT / 'bench/lib/benchlib.py')
benchlib = importlib.util.module_from_spec(spec)
spec.loader.exec_module(benchlib)

def run(args):
    r = subprocess.run(list(map(str, args)), capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr[-4000:] + r.stdout[-4000:])
    return r.stdout

def rpc(code):
    return run(['docker', 'exec', NAME, 'bin/campfire', 'rpc', code])

def load(*args):
    return json.loads(run(['taskset', '-c', LOADGEN, ROOT / 'target/bench/release/loadgen', *args]))

def valid(x):
    assert x['ok'] > 0 and x['errors'] == x['invalid_responses'] == 0 and x['statuses'] == {'200': x['ok']}, x

def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def counters(path):
    return {k: int(v) for k, v in (line.split() for line in path.read_text().splitlines())}

def snapshot(cg):
    cpu = {line.split()[0]: list(map(int, line.split()[1:])) for line in pathlib.Path('/proc/stat').read_text().splitlines() if line.startswith('cpu')}
    groups = {}
    for p in [cg, *cg.parents]:
        if p == pathlib.Path('/sys/fs'): break
        if (p / 'cpu.stat').exists():
            groups[str(p)] = {'stat': counters(p / 'cpu.stat'), 'max': (p / 'cpu.max').read_text().strip() if (p / 'cpu.max').exists() else 'root'}
    processes = {}
    for pid in (cg / 'cgroup.procs').read_text().split():
        try:
            processes[pid] = {'name': benchlib.comm(pid), 'cpu_secs': benchlib.cpu_secs(pid)}
        except OSError: pass
    threads = {}
    for pid, process in processes.items():
        if process['name'] != 'beam.smp': continue
        for thread in pathlib.Path(f'/proc/{pid}/task').glob('*'):
            try:
                fields = (thread/'stat').read_text().rsplit(')',1)[1].split()
                threads[thread.name] = {'name': (thread/'comm').read_text().strip(), 'cpu_secs': (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')}
            except OSError: pass
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {'time': time.time(), 'cpu': cpu, 'cgroups': groups, 'processes': processes, 'threads': threads, 'child_cpu_secs': children.ru_utime+children.ru_stime}

def summarize(a, b, cg, response):
    usage = b['cgroups'][str(cg)]['stat']['usage_usec'] - a['cgroups'][str(cg)]['stat']['usage_usec']
    cpus = {}
    for name, start in a['cpu'].items():
        delta = [y-x for x,y in zip(start,b['cpu'][name])]
        cpus[name] = {'steal_ticks': delta[7], 'steal_pct': 100 * delta[7] / max(sum(delta[:8]),1), 'iowait_pct': 100 * delta[4] / max(sum(delta[:8]),1)}
    groups = {p: {k: v-a['cgroups'][p]['stat'].get(k,0) for k,v in d['stat'].items()} for p,d in b['cgroups'].items()}
    roles = collections.defaultdict(float)
    for pid, d in b['processes'].items():
        if pid in a['processes']:
            roles[d['name']] += d['cpu_secs'] - a['processes'][pid]['cpu_secs']
    thread_cpu = collections.defaultdict(float)
    for tid, d in b['threads'].items():
        if tid in a['threads']:
            thread_cpu[d['name']] += d['cpu_secs'] - a['threads'][tid]['cpu_secs']
    return {'cpu_us_per_success': usage / response['ok'], 'server_cpu_equivalents': usage/1e6/(b['time']-a['time']), 'os_cpu': cpus, 'cgroup_deltas': groups, 'surviving_process_cpu_secs': dict(roles), 'thread_cpu_secs': dict(thread_cpu), 'loadgen_cpu_secs': b['child_cpu_secs']-a['child_cpu_secs']}

def setup(variant, dest):
    while float(pathlib.Path('/proc/loadavg').read_text().split()[0]) >= 1.5:
        time.sleep(10)
    assert not run(['docker','ps','-q']).strip(), 'Competing container'
    for port in [PORT,PORT+1,6379]:
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            s.bind(('127.0.0.1',port))
    if WORK.exists(): shutil.rmtree(WORK)
    shutil.copytree(SEED,WORK)
    with sqlite3.connect(WORK/'db/production.sqlite3') as db:
        db.execute("UPDATE push_subscriptions SET endpoint='https://127.0.0.1:9/push/'||id")
        db.execute("UPDATE webhooks SET url='http://127.0.0.1:9/hook/'||id")
    image = IMAGES['baseline' if variant=='baseline' else 'candidate']
    args = ['docker','run','-d','--name',NAME,'--network','host','--cpuset-cpus',SERVER,'--ulimit','nofile=65536:65536','--user',f'{os.getuid()}:{os.getgid()}','--env-file',ROOT/'parity/reference.env']
    for value in [f'PORT={PORT}',f'HTTP_PORT={PORT}',f'TARGET_PORT={PORT+1}','WEB_CONCURRENCY=3','JOB_CONCURRENCY=3','RAILS_MAX_THREADS=5','RAILS_LOG_LEVEL=warn']:
        args += ['-e',value]
    args += ['-v',f'{WORK}/db:/rails/storage/db','-v',f'{WORK}/storage:/rails/storage/files','-v',f'{ROOT}/var/linux-diagnosis:/diagnosis','-v',f'{OUT}:/diagnostic-results',image]
    run(args)
    for _ in range(600):
        try:
            if urllib.request.urlopen(BASE+'/up',timeout=1).status == 200: break
        except OSError: pass
        time.sleep(.1)
    else: raise RuntimeError('readiness failed')
    if variant=='candidate-pool-off':
        text=rpc('pool = Process.whereis(Campfire.DB.ReadPool); {id, ^pool, _, _} = Enum.find(Supervisor.which_children(Campfire.Supervisor), fn {_, pid, _, _} -> pid == pool end); :ok = Supervisor.terminate_child(Campfire.Supervisor, id); nil = Process.whereis(Campfire.DB.ReadPool); IO.puts(Jason.encode!(%{terminated_child: inspect(id), schedulers: System.schedulers_online(), pool_absent: true}))')
        (dest/'pool-termination.json').write_text(text)
    if variant in ['candidate-pragmas','candidate-nomutex']:
        mode=variant.removeprefix('candidate-')
        text=rpc(f'Code.eval_file("/diagnosis/restart_pool.exs"); LinuxPoolExperiment.restart(:{mode})')
        (dest/'pool-restart.json').write_text(text)
    if variant=='candidate-prototype':
        (dest/'prototype-activation.json').write_text(rpc('Code.eval_file("/diagnosis/activate_prototype.exs")'))
    text=rpc('IO.puts(Jason.encode!(%{elixir: System.version(), otp: File.read!("/usr/local/lib/erlang/releases/29/OTP_VERSION") |> String.trim(), schedulers: System.schedulers_online(), schedulers_total: :erlang.system_info(:schedulers), dirty_cpu_schedulers: :erlang.system_info(:dirty_cpu_schedulers_online), bindings: inspect(:erlang.system_info(:scheduler_bindings)), writer: inspect(Process.whereis(Campfire.DB)), pool: inspect(Process.whereis(Campfire.DB.ReadPool))}))')
    (dest/'runtime.json').write_text(text)
    pid=int(run(['docker','inspect','-f','{{.State.Pid}}',NAME]))
    cg=pathlib.Path('/sys/fs/cgroup')/pathlib.Path(f'/proc/{pid}/cgroup').read_text().strip().split(':',2)[2].lstrip('/')
    affinities={}
    for p in (cg/'cgroup.procs').read_text().split():
        info={}
        for t in pathlib.Path(f'/proc/{p}/task').glob('*'):
            try:
                allowed=next(x.split(':',1)[1].strip() for x in (t/'status').read_text().splitlines() if x.startswith('Cpus_allowed_list:'))
                info[t.name]={'name':(t/'comm').read_text().strip(),'allowed':allowed}
            except (OSError,StopIteration): pass
        affinities[p]={'name':benchlib.comm(p),'threads':info}
    save(dest/'affinity.json',affinities)
    save(dest/'environment.json',{'image':image,'variant':variant,'server_cpus':SERVER,'loadgen_cpus':LOADGEN,'loadavg':pathlib.Path('/proc/loadavg').read_text(),'nofile':resource.getrlimit(resource.RLIMIT_NOFILE)})
    labels=json.loads((SEED/'labels.json').read_text())
    cookie=load('login','--base',BASE,'--email',labels['emails.david'],'--password',labels['passwords.all'])['cookie']
    scrape=load('scrape','--base',BASE,'--cookie',cookie,'--room',labels['rooms.watercooler'])
    run(['python3',ROOT/'bench/validate.py','preflight',BASE,cookie,labels['rooms.watercooler'],labels['messages.busy_060'],labels['avatar_tokens.jason'],scrape['css'],WORK/'db/production.sqlite3',dest/'preflight.json'])
    time.sleep(3)
    return cg,cookie,labels

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=['clean','sample','eprof'],required=True)
    parser.add_argument('--variants',default='baseline,candidate')
    parser.add_argument('--reps',type=int,default=1)
    parser.add_argument('--seconds',type=int,default=4)
    parser.add_argument('--concs',default='1,16,64')
    parser.add_argument('--label',required=True)
    opts=parser.parse_args()
    resource.setrlimit(resource.RLIMIT_NOFILE,(65536,resource.getrlimit(resource.RLIMIT_NOFILE)[1]))
    run(['python3',ROOT/'bench/validate.py','ledger'])
    for rep in range(1,opts.reps+1):
        variants=opts.variants.split(',')
        if rep%2==0: variants.reverse()
        for variant in variants:
            dest=OUT/f'{opts.label}-{variant}-{rep}'
            dest.mkdir(exist_ok=False)
            print(f'{time.strftime("%H:%M:%S")} starting {dest.name}',flush=True)
            try:
                cg,cookie,labels=setup(variant,dest)
                for route,path in [('sidebar','/users/me/sidebar'),('room_show',f'/rooms/{labels["rooms.watercooler"]}')]:
                    args=['http','--base',BASE,'--cookie',cookie,'--path',path]
                    valid(load(*args,'--conc',4,'--duration',2))
                    for conc in ([16] if opts.phase=='eprof' else list(map(int,opts.concs.split(',')))):
                        stem=f'{route}-{conc}'
                        if opts.phase=='sample':
                            rpc(f'Code.eval_file("/diagnosis/sample.exs"); LinuxDiagnostic.sample("/diagnostic-results/{dest.name}/{stem}-beam.json", {opts.seconds+2}000)')
                        if opts.phase=='eprof':
                            rpc('Path.wildcard("/usr/local/lib/erlang/lib/tools-*/ebin") |> Enum.each(fn p -> :code.add_patha(String.to_charlist(p)); :code.load_abs(String.to_charlist(Path.join(p, "eprof"))) end); :eprof.start(); :eprof.start_profiling(:erlang.processes())')
                        start=snapshot(cg)
                        response=load(*args,'--conc',conc,'--duration',opts.seconds)
                        end=snapshot(cg)
                        valid(response)
                        save(dest/f'{stem}.json',{'route':route,'phase':opts.phase,'response':response,'accounting':summarize(start,end,cg,response),'before':start,'after':end})
                        print(f'{time.strftime("%H:%M:%S")} {dest.name} {stem}: {response["rps"]} req/s, {summarize(start,end,cg,response)["cpu_us_per_success"]:.0f} cpu-us/ok',flush=True)
                        if opts.phase=='sample':
                            for _ in range(150):
                                if (dest/f'{stem}-beam.json').exists(): break
                                time.sleep(.1)
                            else: raise RuntimeError('BEAM sampler output missing')
                        if opts.phase=='eprof':
                            (dest/f'{stem}-functions.txt').write_text(rpc(':eprof.stop_profiling(); :erlang.group_leader(Process.group_leader(), Process.whereis(:eprof)); :eprof.analyze(:total, sort: :time); :eprof.stop()'))
            finally:
                subprocess.run(['docker','rm','-f',NAME],capture_output=True)
                if WORK.exists(): shutil.rmtree(WORK)

if __name__=='__main__': main()
